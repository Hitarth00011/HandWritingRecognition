
Training Command:
python main.py --mode train --data_dir path/to/IAM

